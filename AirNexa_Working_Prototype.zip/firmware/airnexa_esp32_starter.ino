/*
 AirNexa ESP32 sensor integration starter (NOT validated for safety use).
 Replace placeholder readGas*() functions with the exact sensor manufacturer's
 library, calibration procedure, and verified units. Never use uncalibrated
 readings for regulatory reporting or automatic safety control.
*/
#include <WiFi.h>
#include <HTTPClient.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* API_ENDPOINT = "http://YOUR_LAPTOP_IP:5000/api/readings"; // optional receiver

// Placeholder pins only. Select sensor modules based on datasheets and interface.
const int SO2_ANALOG_PIN = 34;
const int NO2_ANALOG_PIN = 35;
const int CO2_ANALOG_PIN = 32;

float readGasPlaceholder(int pin) {
  // Raw ADC voltage is NOT a gas concentration. Calibrate with certified gas
  // standards and use the sensor-specific conversion formula before deployment.
  return (float)analogRead(pin) * 3.3f / 4095.0f;
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(500); Serial.print(".");
  }
  Serial.println(WiFi.status() == WL_CONNECTED ? "\nWi-Fi connected" : "\nOffline: serial-only demo");
}

void loop() {
  float so2Voltage = readGasPlaceholder(SO2_ANALOG_PIN);
  float no2Voltage = readGasPlaceholder(NO2_ANALOG_PIN);
  float co2Voltage = readGasPlaceholder(CO2_ANALOG_PIN);
  Serial.printf("Raw sensor voltages (V): SO2=%.3f, NO2=%.3f, CO2=%.3f\n",
                so2Voltage, no2Voltage, co2Voltage);

  // Intentionally sends raw voltage placeholders only; do not label as ppm.
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(API_ENDPOINT);
    http.addHeader("Content-Type", "application/json");
    String body = "{\"mode\":\"raw_voltage_placeholder\",\"so2_v\":" +
      String(so2Voltage, 3) + ",\"no2_v\":" + String(no2Voltage, 3) +
      ",\"co2_v\":" + String(co2Voltage, 3) + "}";
    int code = http.POST(body);
    Serial.printf("POST status: %d\n", code);
    http.end();
  }
  delay(5000);
}
