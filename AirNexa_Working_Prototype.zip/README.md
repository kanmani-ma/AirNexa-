# AirNexa — AI + IoT industrial gas monitoring concept

AirNexa is a prototype concept for monitoring SO₂, NO₂ and CO₂ around industrial exhaust systems, displaying readings, generating advisory alerts, and helping operators inspect gas-treatment equipment.

## What works in this repository
- `web/index.html`: self-contained dashboard demo with simulated gas readings, trend chart, illustrative alerts, and CSV export.
- `firmware/airnexa_esp32_starter.ino`: ESP32 integration starter that prints raw analog voltages and optionally posts placeholders. It is not calibrated gas measurement code.
- `docs/architecture.md`: architecture, limits, and safety notes.

## Run the dashboard
1. Download or clone this repository.
2. Open `web/index.html` in a modern browser. No install/build step is needed.
3. Click **Generate sample reading** to simulate a new data point.
4. Click **Export CSV** to download the demo trend.

## Hardware integration (development only)
1. Choose gas-specific sensors with datasheets and suitable measurement ranges.
2. Follow the manufacturer's warm-up, calibration, cross-sensitivity, temperature/humidity compensation, and maintenance instructions.
3. Connect the sensor interface to an ESP32 only after checking voltage levels and analog/digital interface requirements.
4. Replace the placeholder voltage readings with calibrated concentration calculations.
5. Add an authenticated transport and a receiving API before connecting live hardware.

## Important safety and validity notes
- The dashboard uses random simulated values; it does not detect real pollution.
- The ESP32 sketch reports raw voltage placeholders, not ppm. Sensor-specific calibration is mandatory.
- The dashboard thresholds are illustrative and are not legal/occupational exposure limits.
- This prototype does not remove gases and does not demonstrate scrubber efficiency. A separate engineered treatment stage requires material selection, gas-flow sizing, pressure-drop testing, by-product management, and qualified safety review.
- Do not connect the prototype to industrial control valves or use it for life-safety decisions.
- Any actual field demo should use appropriate PPE, trained supervision, and approved test procedures.

## Technology
HTML, CSS, JavaScript, SVG, ESP32 Arduino framework, Wi-Fi/HTTP (optional integration concept).

## Suggested next steps
- Add a backend API and database for calibrated time-series readings.
- Test with a certified calibration gas setup under qualified supervision.
- Evaluate sensor drift and cross-sensitivity.
- Document the prototype results with real, dated measurements before claiming performance.

## License
MIT License. See `LICENSE`.
