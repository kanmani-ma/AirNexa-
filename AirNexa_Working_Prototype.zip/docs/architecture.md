# AirNexa architecture and evidence plan

## Data flow
Gas-specific sensors → ESP32 acquisition → calibration / compensation → Wi-Fi transport → monitoring dashboard → threshold/trend alert → operator inspection of treatment equipment.

## Modules
1. Sensing: separate sensor modules suitable for SO₂, NO₂ and CO₂, chosen for target range and environment.
2. Edge device: ESP32 collects readings and timestamps.
3. Software: dashboard shows readings, trends, status and downloadable CSV.
4. Decision support: rule-based alerts in the current demo; AI anomaly detection is a future extension requiring a representative labeled dataset.
5. Treatment: separate scrubber / capture stage designed and tested by qualified personnel. The dashboard only supports monitoring; it does not itself remove pollutants.

## Validation plan
- Record sensor make/model, range, accuracy, calibration gas, calibration date and environmental conditions.
- Compare sensor outputs against a reference instrument.
- Test stable, rising and falling concentrations using approved procedures.
- Measure inlet/outlet concentrations and gas flow to calculate removal efficiency.
- Record by-products, pressure drop, water/chemical consumption, maintenance and disposal requirements.
- Do not publish efficiency claims until measured and reproducible.

## Risks and mitigations
- Cross-sensitivity / drift: calibration, reference checks and maintenance.
- False alerts: conservative alerting, data-quality flags and human review.
- Connectivity loss: local buffering and offline indicator.
- Hazardous gases / chemicals: no uncontrolled gas release; trained supervision, appropriate PPE and approved test facilities.
- CO₂ capture and NO₂/SO₂ scrubbing are distinct processes; design them separately rather than claiming one universal absorbent.
